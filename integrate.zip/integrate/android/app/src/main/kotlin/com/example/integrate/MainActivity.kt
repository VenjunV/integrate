package com.example.integrate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
